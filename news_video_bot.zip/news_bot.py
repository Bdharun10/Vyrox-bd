#!/usr/bin/env python3
"""প্রতিদিনের শিরোনাম ভিডিও: RSS -> স্লাইড -> বাংলা ভয়েস -> MP4 -> YouTube.

ব্যবহার:
  python news_bot.py --demo --no-tts          # নেট ছাড়া পরীক্ষা
  python news_bot.py                           # শিরোনাম টেনে ভিডিও বানায় (out/ ফোল্ডারে)
  python news_bot.py --upload --privacy private  # বানিয়ে YouTube-এ আপলোড
"""
import argparse
import asyncio
import datetime as dt
import html
import json
import os
import re
import subprocess
import sys
import zoneinfo
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, features

W, H = 1920, 1080
CHANNEL = "VYROX-BD"
VOICE = "bn-BD-NabanitaNeural"  # বিকল্প: bn-BD-PradeepNeural
BN_DIG = str.maketrans("0123456789", "০১২৩৪৫৬৭৮৯")
BN_MON = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
          "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"]


def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def bn_date(d):
    return f"{d.day} {BN_MON[d.month - 1]} {d.year}".translate(BN_DIG)


# ---------------------------------------------------------------- শিরোনাম সংগ্রহ
def clean(s):
    s = html.unescape(re.sub(r"<[^>]+>", " ", s or ""))
    return re.sub(r"\s+", " ", s).strip()


def collect(feeds_file, per_paper, max_total):
    import feedparser  # দেরিতে ইমপোর্ট, যাতে --demo তে লাগে না

    feeds = json.loads(Path(feeds_file).read_text(encoding="utf-8"))
    items, seen = [], set()
    for source, url in feeds.items():
        if url.startswith("PUT_"):
            print(f"[skip] {source}: feeds.json-এ RSS লিংক বসানো হয়নি")
            continue
        try:
            parsed = feedparser.parse(url, agent="Mozilla/5.0 (VYROX-BD news bot)")
            n = 0
            for e in parsed.entries:
                title = clean(e.get("title"))
                if not title or title in seen:
                    continue
                seen.add(title)
                items.append({"source": source, "title": title, "link": e.get("link", "")})
                n += 1
                if n >= per_paper:
                    break
            print(f"[ok] {source}: {n}টি শিরোনাম")
        except Exception as ex:  # একটা সাইট নষ্ট হলে বাকিগুলো চলবে
            print(f"[warn] {source}: {ex}")
    return items[:max_total]


def demo_items():
    return [
        {"source": "Demo Daily", "title": "Sample headline number one for layout testing", "link": "https://example.com/1"},
        {"source": "Demo Daily", "title": "A much longer sample headline that should wrap across several lines so we can check that the text fitting logic works properly", "link": "https://example.com/2"},
        {"source": "Test Times", "title": "Third sample headline", "link": "https://example.com/3"},
    ]


# ---------------------------------------------------------------- স্লাইড
def find_font():
    if os.getenv("BN_FONT"):
        return os.environ["BN_FONT"]
    out = subprocess.run(["fc-match", "-f", "%{file}", "Noto Sans Bengali:bold"],
                         capture_output=True, text=True).stdout.strip()
    return out or "DejaVuSans-Bold.ttf"


def wrap(draw, text, font, maxw):
    lines, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=font) <= maxw:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def background():
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=(int(8 + 10 * k), int(14 + 20 * (1 - k)), int(36 + 30 * (1 - k))))
    d.rectangle([0, 0, W, 8], fill=(255, 205, 0))
    return img


def paste_logo(img, logo_path, height, xy=None, center=False):
    if not Path(logo_path).exists():
        return
    lg = Image.open(logo_path).convert("RGBA")
    lg = lg.resize((int(lg.width * height / lg.height), height), Image.LANCZOS)
    pos = ((W - lg.width) // 2, (H - lg.height) // 2 - 120) if center else xy
    img.paste(lg, pos, lg)


def make_slide(path, font_path, logo, date_text, source, headline, idx=None, total=None):
    kw = {"layout_engine": ImageFont.Layout.RAQM} if features.check("raqm") else {}
    img = background()
    d = ImageDraw.Draw(img)
    f_small = ImageFont.truetype(font_path, 40, **kw)
    f_tag = ImageFont.truetype(font_path, 46, **kw)

    paste_logo(img, logo, 130, (60, 40))
    d.text((220, 70), CHANNEL, font=f_tag, fill=(255, 205, 0))
    d.text((220, 125), date_text, font=f_small, fill=(200, 210, 230))
    if idx:
        d.text((W - 60, 80), f"{idx}/{total}".translate(BN_DIG), font=f_tag, fill=(200, 210, 230), anchor="ra")

    size = 92
    while True:
        f_head = ImageFont.truetype(font_path, size, **kw)
        lines = wrap(d, headline, f_head, W - 220)
        if (len(lines) <= 5 and len(lines) * size * 1.45 <= 560) or size <= 40:
            break
        size -= 4
    if source:
        tag = f"  {source}  "
        tw = d.textlength(tag, font=f_tag)
        d.rounded_rectangle([110, 270, 110 + tw, 270 + 72], radius=14, fill=(255, 205, 0))
        d.text((110, 306), tag, font=f_tag, fill=(10, 14, 30), anchor="lm")
    y = 390
    for ln in lines:
        d.text((110, y), ln, font=f_head, fill=(255, 255, 255))
        y += int(size * 1.45)
    d.text((110, H - 70), "সূত্র: " + source if source else "", font=f_small, fill=(160, 172, 200))
    img.save(path)


def make_intro(path, font_path, logo, date_text):
    kw = {"layout_engine": ImageFont.Layout.RAQM} if features.check("raqm") else {}
    img = background()
    d = ImageDraw.Draw(img)
    paste_logo(img, logo, 420, center=True)
    f1 = ImageFont.truetype(font_path, 96, **kw)
    f2 = ImageFont.truetype(font_path, 52, **kw)
    d.text((W // 2, 800), "আজকের প্রধান শিরোনাম", font=f1, fill=(255, 205, 0), anchor="mm")
    d.text((W // 2, 900), date_text, font=f2, fill=(255, 255, 255), anchor="mm")
    img.save(path)


# ---------------------------------------------------------------- অডিও ও ভিডিও
async def tts(text, path):
    import edge_tts
    await edge_tts.Communicate(text, VOICE).save(str(path))


def probe_dur(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "default=nw=1:nk=1", str(path)], capture_output=True, text=True).stdout
    return float(out.strip())


def make_segment(png, audio, out, min_dur):
    dur = max(probe_dur(audio) + 0.7, min_dur)
    run(["ffmpeg", "-y", "-loop", "1", "-framerate", "30", "-i", str(png), "-i", str(audio),
         "-t", f"{dur:.2f}", "-vf", "format=yuv420p", "-af", "apad",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
         "-c:a", "aac", "-ar", "44100", "-ac", "2", str(out)])
    return dur


def fmt_time(sec):
    sec = int(sec)
    return f"{sec // 60}:{sec % 60:02d}"


# ---------------------------------------------------------------- YouTube আপলোড
def upload(video, thumb, title, desc, tags, privacy):
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload

    creds = Credentials(
        None,
        refresh_token=os.environ["YT_REFRESH_TOKEN"],
        token_uri="https://oauth2.googleapis.com/token",
        client_id=os.environ["YT_CLIENT_ID"],
        client_secret=os.environ["YT_CLIENT_SECRET"],
        scopes=["https://www.googleapis.com/auth/youtube.upload"],
    )
    yt = build("youtube", "v3", credentials=creds)
    body = {
        "snippet": {"title": title[:100], "description": desc[:4900], "tags": tags,
                    "categoryId": "25", "defaultLanguage": "bn"},
        "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False},
    }
    req = yt.videos().insert(part="snippet,status", body=body,
                             media_body=MediaFileUpload(str(video), chunksize=8 * 1024 * 1024, resumable=True))
    resp = None
    while resp is None:
        status, resp = req.next_chunk()
        if status:
            print(f"আপলোড {int(status.progress() * 100)}%")
    vid = resp["id"]
    print("আপলোড শেষ: https://youtu.be/" + vid)
    try:
        yt.thumbnails().set(videoId=vid, media_body=MediaFileUpload(str(thumb))).execute()
    except Exception as ex:  # থাম্বনেইলের জন্য চ্যানেল ভেরিফাইড হতে হয়
        print("[warn] থাম্বনেইল বসানো যায়নি:", ex)
    return vid


# ---------------------------------------------------------------- মূল প্রবাহ
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feeds", default="feeds.json")
    ap.add_argument("--logo", default="logo.png")
    ap.add_argument("--out", default="out")
    ap.add_argument("--per-paper", type=int, default=5)
    ap.add_argument("--max-total", type=int, default=30)
    ap.add_argument("--demo", action="store_true", help="নমুনা শিরোনাম দিয়ে পরীক্ষা")
    ap.add_argument("--no-tts", action="store_true", help="ভয়েস ছাড়া (নীরব) ভিডিও")
    ap.add_argument("--upload", action="store_true")
    ap.add_argument("--privacy", default="private", choices=["private", "unlisted", "public"])
    a = ap.parse_args()

    if not features.check("raqm"):
        print("[warn] Pillow-তে RAQM নেই: বাংলা যুক্তাক্ষর ভুল দেখাতে পারে (libraqm0 libfribidi0 libharfbuzz0b ইনস্টল করুন)")

    now = dt.datetime.now(zoneinfo.ZoneInfo("Asia/Dhaka"))
    date_text = bn_date(now)
    items = demo_items() if a.demo else collect(a.feeds, a.per_paper, a.max_total)
    if not items:
        sys.exit("কোনো শিরোনাম পাওয়া যায়নি: feeds.json-এ সঠিক RSS লিংক বসান")

    out = Path(a.out)
    out.mkdir(exist_ok=True)
    font = find_font()
    segs, starts = [], {}
    t = 0.0

    def audio_for(i, text):
        p = out / f"a{i:03d}.m4a"
        if a.no_tts:
            run(["ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", "3", "-c:a", "aac", str(p)])
        else:
            mp3 = out / f"a{i:03d}.mp3"
            asyncio.run(tts(text, mp3))
            return mp3
        return p

    # ইন্ট্রো
    png = out / "s000.png"
    make_intro(png, font, a.logo, date_text)
    t += make_segment(png, audio_for(0, f"আজকের প্রধান শিরোনাম। {date_text}।"), out / "seg000.mp4", 4.0)
    segs.append(out / "seg000.mp4")

    # শিরোনাম স্লাইড
    for i, it in enumerate(items, 1):
        png = out / f"s{i:03d}.png"
        make_slide(png, font, a.logo, date_text, it["source"], it["title"], i, len(items))
        starts.setdefault(it["source"], t)
        seg = out / f"seg{i:03d}.mp4"
        t += make_segment(png, audio_for(i, f"{it['source']}। {it['title']}"), seg, 5.0)
        segs.append(seg)
        print(f"স্লাইড {i}/{len(items)} তৈরি")

    lst = out / "list.txt"
    lst.write_text("".join(f"file '{s.name}'\n" for s in segs), encoding="utf-8")
    final = out / "news_video.mp4"
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy",
         "-movflags", "+faststart", str(final)])

    thumb = out / "thumb.jpg"
    Image.open(out / "s000.png").convert("RGB").resize((1280, 720)).save(thumb, quality=90)

    title = f"আজকের প্রধান শিরোনাম | {date_text} | {CHANNEL}"
    lines = [f"📰 {date_text}-এর জাতীয় দৈনিকের প্রধান শিরোনাম।", ""]
    for it in items:
        lines.append(f"• [{it['source']}] {it['title']}")
        if it["link"]:
            lines.append(f"  {it['link']}")
    lines += ["", "শিরোনামগুলোর স্বত্ব সংশ্লিষ্ট পত্রিকার। বিস্তারিত পড়তে উপরের লিংকে যান।",
              "ভিডিওর ভয়েস কৃত্রিম (টেক্সট-টু-স্পিচ)।", "",
              f"চ্যানেল: {CHANNEL}", "#বাংলা_সংবাদ #আজকের_শিরোনাম #BangladeshNews"]
    desc = "\n".join(lines)
    (out / "description.txt").write_text(desc, encoding="utf-8")
    tags = ["আজকের শিরোনাম", "বাংলা সংবাদ", "bangladesh news", "headlines today", CHANNEL]

    print(f"ভিডিও তৈরি: {final} ({fmt_time(t)})")
    if a.upload:
        upload(final, thumb, title, desc, tags, a.privacy)


if __name__ == "__main__":
    main()

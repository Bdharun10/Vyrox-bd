"""একবারই চালাতে হবে (নিজের কম্পিউটারে)।
client_secret.json (Google Cloud > Credentials > OAuth client ID > Desktop app) এই ফোল্ডারে রাখুন।
যে রিফ্রেশ টোকেন প্রিন্ট হবে সেটা GitHub Secret-এ YT_REFRESH_TOKEN নামে রাখুন।"""
from google_auth_oauthlib.flow import InstalledAppFlow

flow = InstalledAppFlow.from_client_secrets_file(
    "client_secret.json", ["https://www.googleapis.com/auth/youtube.upload"]
)
creds = flow.run_local_server(port=0)
print("\nYT_REFRESH_TOKEN =", creds.refresh_token)
